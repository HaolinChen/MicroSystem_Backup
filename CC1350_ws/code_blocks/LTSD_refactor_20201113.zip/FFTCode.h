#ifndef FFTCodeH
#define FFTCodeH

void kfft(double pr[],double pi[],int n,int k,double fr[],double fi[]);

#endif

