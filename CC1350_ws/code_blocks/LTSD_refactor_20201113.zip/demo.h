#ifndef DEMO_H_INCLUDED
#define DEMO_H_INCLUDED

int matrix_c_demo(void);

#endif // DEMO_H_INCLUDED
